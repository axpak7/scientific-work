function y = solution(x)

    y = x + sqrt(1 + 2 * x^2);

end