function y = dydx(x, y_prev)

   y = (y_prev + x)/(y_prev - x);
   
end